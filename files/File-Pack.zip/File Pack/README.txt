Here you have to copy all the files to System32 in Windows 2000 execpt d3d9.dll.
Instead, copy d3d9.dll to the folder were all the sonic generations game files are.